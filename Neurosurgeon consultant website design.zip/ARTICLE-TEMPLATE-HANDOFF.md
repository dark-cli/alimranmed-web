# Article template — extraction instructions

For the agent that migrates `src/content/treatments/*/{en,ar}.md` (and `posts/*`) onto the
new article layout. The layout is `Article Template.dc.html`; it renders **any** of the
~300 articles from the markdown alone. Nothing below requires rewriting article prose.

---

## 1. Fields the template needs

| Template slot | Source | Rule |
|---|---|---|
| Title | `title` frontmatter | verbatim |
| Standfirst | `description`, or body paragraph 1 | see §1a — **always de-duplicate** |
| Breadcrumb / category chip | `category` | map to a label — see §2 |
| Pathway | `category` | map to pathway string — see §2 |
| Reviewed by | constant | `Hussein Imran Mousa, consultant neurosurgeon` / `الدكتور حسين عمران موسى، استشاري جراحة الجهاز العصبي` |
| Reading time | body word count | `max(1, round(words / 200))`. Strip image markdown before counting. Render Arabic numerals (٦) in `ar`. |
| Last reviewed | `publishedAt` | format as month + year. If absent, omit the row — do not invent a date. |
| On this page (TOC) | generated | one entry per `h2` after normalisation — see §3 |

`order`, `legacyUrl` and `source` are not displayed. Keep `legacyUrl` for redirects.

### 1a. Standfirst — the de-duplication rule

The legacy WordPress `description` is an auto-excerpt of the article's first paragraph,
cut at a fixed character count. In `acoustic-neuroma/en.md` it ends mid-sentence:
*"…and is also called"*. Most `ar.md` files have no `description` at all. So:

1. Normalise whitespace on `description` and on body paragraph 1.
2. If `description` is empty, **or** paragraph 1 starts with it, **or** it starts with
   paragraph 1 — they are the same text. Build the standfirst from **paragraph 1**,
   trimmed to the last complete sentence within ~240 chars, and **remove paragraph 1
   from the body**.
3. Only when `description` is genuinely independent prose does it stand as written, with
   paragraph 1 left in the body.

Never print a mid-sentence excerpt as the lead line, and never let the article open by
saying the same thing twice — a patient reads that as a broken page.

## 2. Category maps

```
pain  → label "Pain",  pathway "Pain — interventional"
brain → label "Brain", pathway "Brain — neurosurgical"
spine → label "Spine", pathway "Spine — surgical"

الألم          → "الألم",          "الألم — التدخلي"
الدماغ         → "الدماغ",         "الدماغ — الجراحي"
العمود الفقري  → "العمود الفقري",  "العمود الفقري — الجراحي"
```

Roughly 90 of the treatment files are `category: "pain"`. Re-categorising them is a
content decision, not a migration one — leave it to the clinic, but flag it: the
breadcrumb is far more useful once brain/spine/pain are accurate.

## 3. Body normalisation — the important part

The legacy markdown has almost **no real headings**. `acoustic-neuroma/en.md` has zero
`##` lines; structure is implied by `**bold**` lines and `•` characters. The template's
parser applies these rules, in this order. Re-implement them in the Astro pipeline
(a remark plugin) so the rendered HTML matches:

1. **Front image** → `figure`. A `![](…)` line becomes a figure. Legacy filenames carry
   their pixel width (`…-300x210.jpg`), so cap the figure at that intrinsic width
   (max 420px) rather than stretching a 300px thumbnail across the column. Caption it as
   a legacy asset. Supply a file ≥1600px wide to let it run full column width.
2. **Hard line breaks are paragraph breaks.** Legacy lines end with two spaces. Treat a
   trailing `  ` as the end of a paragraph, not a `<br>`.
3. **Bullets**: `-`, `*`, `+`, `•`, and `1.` all become list items. The literal `•`
   character at line start is the most common form in these files.
4. **Bold lead-ins**: `**Term**. Explanation…` → the term renders as a bold line above
   its explanation (inside a list item) or as a bold lead inside a paragraph.
5. **Bold-only line → `h2`.** A paragraph that is entirely bold, under ~110 chars
   (`**There are 2 types of acoustic neuromas:**`, `**علاج أورام العصب السمعي**`) is
   promoted to a section heading. This is what generates the TOC on articles that have
   no headings of their own.
6. **A bold lead-in with no text that precedes a list** is also promoted to `h2`.
7. `##` → `h2`, `###`/`####` → `h3`, `>` → pull quote. Already-structured articles work
   unchanged.
8. Inline `**`, `*`, `` ` ``, and `[text](url)` are unwrapped to plain text where they
   are decorative. Real links inside list items keep their `href`.
9. A bare YouTube watch/short URL on its own line → 16:9 `youtube-nocookie` embed,
   `loading="lazy"`.

### If an article ends up with fewer than two headings
The TOC hides itself below 820px anyway, and with 0–1 headings it adds nothing. Either
leave it out for that article, or have the agent propose 2–4 headings from the existing
paragraphs **as a content suggestion for review** — do not silently invent medical
section titles.

## 4. Images

- Up to three figures per article.
- **Captions come from the markdown alt text — `![caption](src)`. When alt is empty
  (every legacy `![](…)`), render no `figcaption` at all.** Never emit template guidance
  or migration notes into the article body; a patient reads those as clinic copy.
- Legacy thumbnails render at their intrinsic width (capped at 420px) rather than
  upscaled — deliberately. A blurry 300px image stretched to 740px reads as neglect.
  Supply a file ≥1600px wide to have it run the full column width.
- Where no image exists, render nothing. Do not add stock imagery.

## 5. Layout behaviour (already handled, for reference)

- Two columns with a sticky TOC above 820px of **container** width; single column below,
  TOC hidden. Driven by a CSS container query, not JS.
- RTL: `dir="rtl"` on the root flips the grid, the meta rail border, the breadcrumb
  separator and the blockquote rule. Phone numbers and Latin names stay `dir="ltr"`.
- Type: Newsreader + IBM Plex Sans/Mono for `en`; Amiri + IBM Plex Sans Arabic for `ar`,
  with a looser line-height (1.95 vs 1.72) because Arabic needs it.
- Every article ends with the call CTA and the medical disclaimer. Both are template
  furniture, not per-article content.
