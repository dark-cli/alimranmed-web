# Alimran Clinic — design handoff

For the agent implementing this design in `dark-cli/alimranmed-web` (Astro + content
collections). Companion doc: `ARTICLE-TEMPLATE-HANDOFF.md` covers the markdown→article
pipeline in detail; this doc covers everything else.

Reference implementations in this project — open them, they are the source of truth:

| File | What it is |
|---|---|
| `Alimran Neurosurgery.dc.html` | Home, Consultant CV, Conditions & Procedures (English) |
| `Alimran Neurosurgery AR.dc.html` | The same three screens in Arabic RTL |
| `Article Template.dc.html` | Markdown-driven article layout, EN + AR |
| `Mobile Preview.dc.html` | The site inside a 390×844 phone frame |

> These are React-flavoured HTML written for a design tool. **Do not port the files.**
> Port the values, the structure and the rules below into Astro components.

---

# Part 1 — The thinking

This is the part that matters more than the CSS. If you change the visual details but
keep these decisions, the redesign still works. If you keep the CSS and lose these, it
does not.

## 1.1 The site belongs to the clinic; the doctor is its credibility

The old site was organised around Hussein Imran Mousa. The new one is organised around
**Alimran Clinic**, with him as lead consultant. Practically:

- Masthead reads *Alimran Clinic / Neurosurgery & Pain Medicine · Basra*.
- The home hero describes what the clinic does. He appears beneath it as a 52px circular
  avatar and one line — *"Led by Hussein Imran Mousa, consultant neurosurgeon"* — with a
  link to his CV.
- His full CV, publications, memberships and conference history live on **one dedicated
  page**, not on the home page.

Rationale: a clinic outlives a CV, referrers search for services, and patients want to
know what happens to them. The credentials still do their job from one link away.

## 1.2 Three pathways: Brain / Spine / Pain

Every condition the clinic treats is sorted into one of three pathways. This single
decision does most of the organisational work on the site:

- **Conditions & Procedures** page = three columns, one per pathway.
- Home page shows the same three as compact chip groups.
- Article breadcrumb and the "Pathway" meta row derive from it.
- It matches how referrals actually arrive and how a patient self-identifies. Nobody
  arrives thinking "I need stereotactic functional neurosurgery"; they arrive with back
  pain.

⚠️ **Content blocker:** roughly 90 of the ~300 `treatments/*` files are
`category: "pain"`, including brain tumours and stroke. The pathway system only pays off
once these are accurate. Re-categorising is a clinical decision for the clinic — surface
it to them, do not guess.

## 1.3 The CV as a register, not prose

A 25-year CV written as paragraphs is unreadable. Every CV-type section is a
**two-column register**: a fixed narrow left column for the time or label, a flexible
right column for the content, one hairline rule between rows.

```
2006 — present   │ Consultant Neurosurgeon, Alsadr Teaching Hospital, Basra…
2022 — present   │ Iraq Director, Middle East Stereotactic and Functional…
1999 — 2000      │ Senior House Officer, General Surgery, Basrah General…
```

The section label ("Appointments", "Education", "Memberships") sits in a **sticky
left-hand column** so it stays visible while the rows scroll past it. This is the pattern
the client specifically approved — reuse it anywhere there is a list of dated or labelled
facts. It also collapses cleanly: below 820px the label sits above its rows.

## 1.4 Numbered sections

Every major section on every page opens with the same device: a mono two-digit number, a
serif heading, and a 1px full-width rule beneath both.

```
01  ────────────────────────────────────────────
    Care under one roof
```

Cheap, consistent, and it gives a long page a spine. Numbers restart at 01 per page.

## 1.5 Hairlines, not cards

There are no drop shadows, no rounded cards, no coloured left-border callouts anywhere in
this design. Structure is made of 1px rules (`#dde4e7`) and 1px grid gaps over a
`#dde4e7` background. Radius is `2px` on buttons only — effectively square.

Rationale: it reads as clinical and documentary rather than as a marketing page, which is
what a neurosurgical practice should look like. It is also far more robust — a grid of
hairline cells survives any content length; a grid of shadowed cards does not.

## 1.6 The "at a glance" principle

Anywhere a patient must orient quickly, the page leads with a compressed summary before
the prose: the home page's four-stat band, the article's meta rail (pathway / reviewed by
/ reading time / last reviewed), the "On this page" list. **The client called out the
meta rail and the TOC specifically.** Both are generated, not authored — see
`ARTICLE-TEMPLATE-HANDOFF.md`.

## 1.7 Honest placeholders

Where real photography does not exist, the design renders a labelled diagonal-hatch slot
saying exactly what belongs there and at what size. It does **not** use stock imagery, AI
imagery, or stretch a 300px legacy thumbnail to fill a hero. Keep this discipline — an
empty labelled slot is a task; a bad stock photo is a lie that nobody ever fixes.

---

# Part 2 — Design tokens

## 2.1 Colour

| Token | Hex | Use |
|---|---|---|
| Ink | `#101c22` | Headings, primary text, footer background, section rules |
| Body | `#3c4a52` | Body copy, nav links |
| Muted | `#77858c` | Labels, captions, meta, section numbers |
| Accent | `#0b5e78` | Links, buttons, eyebrows, stat figures, active states |
| Accent hover | `#07445a` | Button hover, link hover |
| Line | `#dde4e7` | All hairline borders, grid gaps |
| Line soft | `#eef2f4` | Rules inside cards (lighter, secondary) |
| Line strong | `#c7d4d9` | Secondary button borders |
| Surface | `#f4f7f8` | Tinted bands, aside cards, stat band |
| White | `#ffffff` | Page and card background |
| Footer text | `#d7e2e6` | On `#101c22` |
| Footer muted | `#a8b8bf` / `#7f929a` | Footer body / footer labels |
| Footer rule | `#22333c` | Divider inside footer |
| Selection | `#cfe4ea` | `::selection` background |

Two backgrounds only: `#ffffff` and `#f4f7f8`, plus `#101c22` for the footer. Do not add
a third.

## 2.2 Type — English

```
Display   Newsreader, serif            400 weight, letter-spacing -0.02em to -0.025em
Body      "IBM Plex Sans", system-ui   400 / 500 / 600
Meta      "IBM Plex Mono", monospace   400 / 500, uppercase, letter-spacing 0.10–0.14em
```

Google Fonts: `Newsreader:opsz,wght@6..72,400;6..72,500`,
`IBM+Plex+Sans:wght@400;500;600`, `IBM+Plex+Mono:wght@400;500`.

| Role | Size | Line height | Notes |
|---|---|---|---|
| Home hero h1 | `clamp(30px, 7.6cqw, 58px)` | 1.06 | `cqw` — see §3.3 |
| Page h1 (CV) | `clamp(28px, 9cqw, 54px)` | 1.07 | |
| Page h1 (Conditions) | `clamp(30px, 5vw, 52px)` | 1.08 | |
| Article h1 | `clamp(29px, 7cqw, 54px)` | 1.08 | |
| Section h2 | `clamp(24px, 3.4vw, 34px)` | — | with number + rule |
| Article body h2 | `clamp(22px, 2.9vw, 29px)` | — | |
| Card h2/h3 | `clamp(21px, 2.6vw, 26px)` / `20–26px` | — | |
| Stat figure | `clamp(30px, 3.4vw, 40px)` | 1 | Newsreader, accent |
| Standfirst | `clamp(16.5px, 1.9vw, 19px)` | 1.6 | |
| Body | `17px` | 1.7 (1.65 on marketing pages) | max-width 52–62ch |
| List / register row | `15–16px` | 1.55–1.6 | |
| Secondary / caption | `13.5–14px` | 1.5–1.75 | |
| Eyebrow / meta label | `10.5–11px` | — | mono, uppercase, tracking 0.12em |
| Nav | `14px` | — | |

**Never below 13.5px.** Mobile nav rows and buttons are `16–17px`.

## 2.3 Type — Arabic

Arabic is not the Latin scale with a different font. It needs a larger base, looser
leading, and heavier display weight.

```
Display   Amiri, serif                        700 weight (not 400)
Body      "IBM Plex Sans Arabic", system-ui   400 / 500 / 600
Meta      "IBM Plex Sans Arabic"              — no monospace, no uppercase
```

| Property | English | Arabic |
|---|---|---|
| Display weight | 400 | **700** |
| Display line-height | 1.06–1.08 | **1.20–1.22** |
| Body line-height | 1.70 | **1.95** |
| Standfirst line-height | 1.60 | **1.90** |
| Meta letter-spacing | 0.12em | **0.02em** |
| Meta text-transform | uppercase | **none** |
| Masthead size | 17px | **19px** |

- `text-transform: uppercase` does nothing in Arabic and the extra tracking damages
  letter joining — both are disabled.
- Numerals are Arabic-Indic: `٠١`, `٥٠٠٠`, `٢٠٢١`, `٦٦٪`.
- Reading time needs real pluralisation: `دقيقة واحدة` (1), `دقيقتان` (2),
  `٣ دقائق` (3–10), `١١ دقيقة` (11+).
- Phone numbers, emails and Latin society names (`AANS`, `AOSpine`, `FIBMS`) must carry
  `dir="ltr"` or they render scrambled inside RTL text.

## 2.4 Spacing

- Page gutter: `24px`. Content max-width: `1180px`.
- Section vertical rhythm: `clamp(48px, 6vw, 88px)` top, `clamp(56px, 7vw, 96px)` on the
  last section before the footer.
- Header/hero: `clamp(44px, 5.5vw, 72px)`.
- Card padding: `26–34px` (`clamp(24px,3vw,32px)` where it must shrink).
- Column gap: `clamp(32px, 4vw, 64px)`. Grid-cell gap: `1px` (the hairline trick).
- Register row padding: `14–18px` vertical.

## 2.5 Controls

| Element | Spec |
|---|---|
| Primary button | bg `#0b5e78`, text `#ffffff`, `min-height:48px`, `padding:0 24px`, `radius:2px`, `font-size:15px/500`; hover bg `#07445a` |
| Secondary button | bg `#ffffff`, text `#0b5e78`, `border:1px solid #c7d4d9`; hover border `#0b5e78` |
| Header button | `min-height:40–44px`, `padding:0 18px`, `font-size:14px` |
| Mobile nav row | `min-height:56px`, `font-size:17px`, `border-bottom:1px solid #eef2f4` |
| Text link | `#0b5e78`; hover `#07445a` + underline |
| Quiet link | no underline, `border-bottom:1px solid #c7d4d9`; hover border `#0b5e78` |

**Every tappable target is ≥44px, most are 48–56px.** Define `a` and `a:hover` globally
or editor-added links render browser-blue.

---

# Part 3 — Layout system

## 3.1 The one grid rule

Almost every multi-column block is:

```css
display: grid;
grid-template-columns: repeat(auto-fit, minmax(min(240px, 100%), 1fr));
gap: 1px;              /* or 20–40px where cells aren't hairline-joined */
background: #dde4e7;   /* only when gap:1px — this paints the rules */
border: 1px solid #dde4e7;
```

The `min(240px, 100%)` is load-bearing: a bare `minmax(240px, 1fr)` overflows below
240px. Minimums used: 175px (stat band, footer), 240px (service cards, facility slots),
255px (pathway columns), 270px (two-up text).

## 3.2 Breakpoints — container, not viewport

**980px** — home hero switches from stacked to two-column.
**860px** — header switches to the hamburger drawer.
**820px** — article switches to two-column with sticky TOC.

Measure the **container**, not the viewport. Two bugs during this design came from
`100vw`/media queries desynchronising from the real available width (inside the phone
frame, inside an embed, at zoom). In Astro you will usually be full-width so media
queries are fine — but the article layout uses a CSS **container query**, which is more
robust and costs nothing:

```css
.wrap { container-type: inline-size; }
.grid { display: grid; grid-template-columns: minmax(0,1fr); }
@container (min-width: 820px) {
  .grid { grid-template-columns: minmax(0,240px) minmax(0,1fr); }
  .grid > article { max-width: 740px; }
  .aside { position: sticky; top: 96px; }
  .toc { display: flex; }
}
```

⚠️ Inline styles beat `@container` rules. Declare `display` and `grid-template-columns`
in the stylesheet, not inline, or the query silently does nothing.

## 3.3 `cqw` for headlines

Hero headlines size against their **container** (`7.6cqw`) rather than the viewport, so
the text never overflows its own column when the grid reflows. Requires
`container-type: inline-size` on the text column. Use `cqw` for any headline inside a
grid cell; `vw` is fine for full-bleed headings.

## 3.4 Mobile specifics

- Hamburger drawer below 860px; 48px button, full-width 56px rows, a solid call button at
  the bottom of the drawer.
- **On mobile the hero photo comes first** — image, then headline, then buttons. Use
  `order: -1` on the photo below the two-column breakpoint.
- Floating call button, bottom-{left in RTL/right in LTR}, 56px circle (icon only) on
  mobile, pill with label on desktop. **It fades in only near the footer**
  (`total − (scrollY + viewportHeight) < viewportHeight × 1.15` and scrolled past half a
  screen) — deliberately not a permanent sticky bar. The phone numbers also live in the
  footer, so the button is a shortcut, not the only route.

---

# Part 4 — Page structures

## 4.1 Home

```
Header (sticky)
Hero              clinic proposition + 2 buttons + doctor credit strip | clinic photo
Stat band         4 cells, #f4f7f8, 1px gaps — 5,000+ / 25 / 4 / 6
01 Care under one roof     4 service cards: Neurosurgery · Interventional pain ·
                           Neuromodulation · Recovery & therapy (5 procedures each)
02 Conditions we treat     3 pathway chip groups → link to Conditions page
03 Inside the clinic       4 facility photo slots + location facts register + map link
04 The lead consultant     short highlight + 4-row register → link to CV page
Referral band              for referring clinicians + secretary numbers + email
Footer
```

Content sources: `src/content/services/*` (surgery, radiofrequency, physiotherapy,
natural-therapy, regenerative-medicine, ozone-therapy, fitness, brain-stimulation),
`src/content/doctors/hussein-imran-mousa/en.md`, `src/consts.ts`.

Keep the home page **about the clinic**. The doctor gets the credit strip plus section 04
— nothing more. This was iterated on three times to get there.

## 4.2 Consultant CV

```
Header: eyebrow "Lead consultant · Clinical profile" + name + role + qualification chips
        | portrait slot (4:5)
Appointments   ┐
Education      │ all five use the sticky-label register (§1.3)
Memberships    │ (memberships is a 2-column list with year on the right)
Publications   │
Conferences    ┘
```

All of it is already in `doctors/hussein-imran-mousa/en.md` and `ar.md`.

## 4.3 Conditions & Procedures

```
Tinted intro band   #f4f7f8 — "What we assess, and how we treat it"
3 pathway columns   Brain / Spine / Pain, 7 conditions each, hairline rows
01 Surgical & advanced procedures    3 cards with 4:3 image slots
02 Interventional pain register      12 numbered procedures, two columns
Appointment band
```

Each condition should link to its `treatments/<slug>` article once the categories are
fixed.

## 4.4 Article

See `ARTICLE-TEMPLATE-HANDOFF.md`. Summary:

```
Breadcrumb: Home › Conditions treated › <category>
h1 + standfirst          | meta rail: Pathway / Reviewed by / Reading time / Last reviewed
[sticky TOC + call card] | article body rendered from markdown
                           CTA band
                           disclaimer
```

---

# Part 5 — Behaviour

| Behaviour | Rule |
|---|---|
| Header | `position:sticky; top:0`, `rgba(255,255,255,.96)` + `backdrop-filter: blur(8px)`, 1px bottom rule |
| Sticky section labels | `top: 96px` (clears the 72px header + breathing room) |
| Anchor targets | `scroll-margin-top: 96px` on every `h2` with an id |
| Nav change | closes the mobile drawer, resets scroll to top, hides the floating call button |
| Floating call | fades + 12px translate, 220ms ease; `pointer-events:none` when hidden |
| TOC | hidden when an article has fewer than 2 headings |
| Language switch | `عربي` / `English` in both header and footer |
| Reduced motion | the only transitions are the call button fade and colour hovers — safe |

---

# Part 6 — RTL

Everything mirrors. The specifics that are easy to miss:

- `dir="rtl"` on the root element; use CSS logical properties (`padding-inline-start`,
  `border-inline-start`) rather than the JS side-swapping the prototype does.
- Breadcrumb separator flips `›` → `‹`.
- Blockquote and meta-rail rules move to the right edge.
- Floating call button moves to bottom-**left**.
- Phone numbers, emails, `AANS`/`AOSpine`/`FIBMS`/`NF2`: wrap in `dir="ltr"`.
- Arabic type scale per §2.3 — this is the part most RTL implementations skip.

**The Arabic copy in the prototype is a draft.** Terminology taken from your own `ar.md`
files is correct (`الجراحة`, `إدارة الألم`, `إعادة التأهيل`, `مركز العمران الطبي`, nav
labels from `src/i18n/ar.json`). Everything newly written needs the doctor's review
before launch. The prototype carries a banner saying so — remove it when the copy is
approved.

---

# Part 7 — Suggested build order

1. **Tokens + base layout** — colours, both font stacks, the `auto-fit` grid helper, the
   sticky header, the footer. Everything else depends on these.
2. **Article template** — highest leverage: one component, ~300 pages. Follow
   `ARTICLE-TEMPLATE-HANDOFF.md`; implement the normalisation as a remark plugin so the
   rendered HTML is clean and cacheable.
3. **Conditions & Procedures** — establishes the pathway taxonomy the articles link into.
4. **Home**.
5. **Consultant CV**.
6. **Contact & location, FAQ** — not designed; build them from the patterns above. Contact
   wants the location facts register from Home §03, a map, and the secretary numbers. FAQ
   wants the hairline register with question as the label column, or a simple
   `<details>` list styled with the same rules.
7. **Arabic** — as a locale layer, not a fork, once the EN pages are stable.

---

# Part 8 — Outstanding, not solvable in code

1. **Clinic photography** — 5 slots: exterior/reception, consulting room, procedure room,
   therapy gym, and a 4:5 portrait of the consultant. Minimum 1600px wide.
2. **Category data** — the `pain` over-assignment in §1.2.
3. **Arabic copy review** — §6.
4. **Article images** — legacy files are 300px thumbnails and render small by design.
   Replacements should be ≥1600px.
5. **About page** — recommended *only* if the clinic can supply the founding story, the
   team beyond the lead consultant, equipment, and accreditations. Otherwise the material
   on the home page covers it, and a page of generic reassurance is worse than no page.
