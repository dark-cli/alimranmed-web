# What to hand the implementing agent

Give it this whole folder. Read order:

1. **`HANDOFF.md`** — design rationale, tokens, layout system, page structures, build order.
2. **`ARTICLE-TEMPLATE-HANDOFF.md`** — the markdown→article pipeline for the ~300 treatment pages.
3. **`reference/*.png`** — what the pages should look like.
4. **`*.dc.html`** — the live prototypes. Open in a browser (they need `support.js`
   beside them). Read them for exact values; **do not port the markup** — it is written
   for a design tool, not for Astro.
5. **`github.md`** — which repo files each screen was built from.

## Reference screenshots

| File | Screen |
|---|---|
| `01-home.png` | Home (English, desktop) |
| `02-conditions-procedures.png` | Conditions & Procedures |
| `03-consultant-cv.png` | Consultant CV |
| `04-home-arabic.png` | Home (Arabic RTL) |
| `05-article-en.png` | Article template, `acoustic-neuroma/en.md` |
| `06-article-ar.png` | Article template, `acoustic-neuroma/ar.md` |
| `07-mobile-home.png` | Home at 390×844 — hamburger, stacked hero, photo first |

## Assets

**There are no new assets to import.** Every image here came from your own repo:

- `public/images/doctors/hussein-imran-mousa.jpg`
- `public/images/legacy/2021/01/…-300x210.jpg` and `public/assets/images/maxresdefault-300x225.jpg`
  (the two images referenced by the acoustic-neuroma articles, copied so the demo renders)

Fonts are all Google Fonts — exact families and weights in `HANDOFF.md` §2.2 and §2.3.

The diagonal-hatch boxes in the screenshots are **not** assets. They are labelled slots
marking photography the clinic still needs to supply: clinic exterior/reception,
consulting room, procedure room, therapy gym, and a 4:5 portrait. Minimum 1600px wide.
Do not substitute stock imagery.
