repo: dark-cli/alimranmed-web
branch: main

## Last sync
date: 2026-09-15T00:40:00Z

### Updated in this project
- Parser rule added: a lone short bullet followed by prose (• Radiosurgery, • Observation, • الجراحة) is promoted to h2 — this is what gives legacy articles their real section structure and TOC.
- Copied the two legacy images referenced by acoustic-neuroma/{en,ar}.md so the demo figures resolve; Arabic reading-time now uses correct duals/plurals and Arabic-Indic year digits.
- Article Template.dc.html rebuilt as a markdown renderer: it parses raw treatments/*.md (frontmatter + body) at runtime and lays out any of the ~300 articles — no per-article design. EN/AR switch loads the real en.md / ar.md.
- Legacy normalisation handled in the parser: literal • bullets, two-space hard breaks, **bold** lines promoted to h2 (which generates the TOC on articles with no headings), bold lead-ins, legacy thumbnails capped at intrinsic width, YouTube URLs to lazy embeds.
- ARTICLE-TEMPLATE-HANDOFF.md written: field-by-field md → template mapping and normalisation rules for the migration agent.
- Treatment article template added (Treatment Article.dc.html), built from src/content/treatments/fibromyalgia/{en,ar}.md — the pattern covers all 107 treatment pages. Bilingual EN/AR in one component with a live toggle.
- Legacy prose given structure: at-a-glance card, sticky TOC, active-vs-latent comparison pair, 66/80/85% stats pulled out of the prose, key-facts register, and the trailing bullet list of treatments rebuilt as a four-group module.
- Arabic RTL version added (Alimran Neurosurgery AR.dc.html): all three screens mirrored, Amiri + IBM Plex Sans Arabic, Arabic-Indic numerals, LTR-isolated phone numbers, language toggle in header and footer of both versions.
- Arabic terminology taken from repo ar.md service titles and src/i18n/ar.json; newly written Arabic copy is flagged in-page as a draft translation.
- Home page is now clinic-led: clinic hero, "Inside the clinic" facility section, doctor reduced to a credit strip plus one highlight block.
- Home page rebuilt around what the clinic does, using the repo's real service taxonomy (surgery, radiofrequency, physiotherapy, regenerative medicine, ozone, fitness) instead of doctor detail.
- Doctor detail reduced to a short highlight block; full CV, publications and training live on the Consultant CV page.
- Site reframed as Alimran Clinic, with Hussein Imran Mousa as lead consultant.
- Mobile pass: hamburger drawer, stacked hero with photo first, floating call button near the footer.

## Screen map
| Screen | Built from |
| --- | --- |
| Home | src/content/services/{surgery,radiofrequency,physiotherapy,natural-therapy,fitness}/en.md, src/content/doctors/hussein-imran-mousa/en.md, src/consts.ts |
| Consultant CV | src/content/doctors/hussein-imran-mousa/en.md |
| Conditions & Procedures | src/data/header-nav.ts, src/content/services/surgery/en.md, src/content/doctors/hussein-imran-mousa/en.md |
| Article template (all treatments + posts) | src/content/treatments/acoustic-neuroma/{en,ar}.md (embedded verbatim as the demo), pattern verified against src/content/treatments/fibromyalgia/{en,ar}.md |
| Arabic (all screens) | src/i18n/ar.json, src/content/services/{surgery,pain-management,rehabilitation,brain-stimulation}/ar.md, src/content/doctors/hussein-imran-mousa/ar.md |
| Article template (EN + AR) | src/content/treatments/fibromyalgia/en.md, src/content/treatments/fibromyalgia/ar.md — pattern applies to all src/content/treatments/* and src/content/posts/* |

## Sync history
- 2026-09-14T02:01:34Z — initial redesign: three screens, palette and type from src/styles/global.css, 4 images copied from public/images/.
